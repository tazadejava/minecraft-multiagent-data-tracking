java -Xms2G -Xmx4G -XX:+UseConcMarkSweepGC -DIReallyKnowWhatIAmDoingISwear=true -jar paper.jar nogui
